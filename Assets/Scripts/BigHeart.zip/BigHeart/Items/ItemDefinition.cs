﻿using CMD.Entities;
using UnityEngine;

namespace BigHeart
{

    [CreateAssetMenu(menuName = "CMD.Core/Item", fileName = "Item_")]
    public class ItemDefinition : EntityDefinitionSO
    {

    }
}
