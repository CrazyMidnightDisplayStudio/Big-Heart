﻿using CMD.Entities;

namespace BigHeart
{
    public class ItemRuntime : BaseEntityRuntime
    {

    }
}
