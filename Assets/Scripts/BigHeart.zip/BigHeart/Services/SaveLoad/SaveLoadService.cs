﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMD.Base;
using CMD.Core;
using CMD.SaveLoadSystem;
using CMD.Services;
using UnityEngine;

namespace BigHeart.Services
{
    /// <summary>Оркестратор: собирает чанки, пишет/читает, создаёт сущности, раскладывает по контейнерам, затем раздаёт остальным компонентам.</summary>
    public sealed class SaveLoadService : ISaveLoadService
    {
        private readonly ISaveLoadStrategy _strategy;

        public SaveLoadService(ISaveLoadStrategy strategy) => _strategy = strategy;

        public void SaveGame()
        {
            var parts = UnityEngine.Object.FindObjectsOfType<MonoBehaviour>(true)
                .OfType<ISaveLoadObject>()
                .ToArray();

            _strategy.Save(parts);
        }

        public void LoadGameFresh()
        {
            var chunks = _strategy.Load() ?? Array.Empty<SaveLoadData>();

            // (1) удалить текущие runtime-сущности
            foreach (var e in UnityEngine.Object.FindObjectsOfType<BaseEntityRuntime>(true))
                UnityEngine.Object.Destroy(e.gameObject);

            // (2) создать сущности из entity-чанков
            var entityChunks = chunks.Where(c => c.Type == ESaveType.entity || c.Id.StartsWith("entity:", StringComparison.Ordinal)).ToList();
            var otherChunks = chunks.Except(entityChunks).ToList();

            var created = new Dictionary<string, BaseEntityRuntime>(entityChunks.Count);

            // типизированные зависимости (под предметы); при необходимости — расширишь
            var itemCatalog = ServiceRegistry.Get<ICatalog<BigHeart.ItemDefinition>>();
            var itemFactory = ServiceRegistry.Get<IEntityFactory<BigHeart.ItemRuntime, BigHeart.ItemDefinition>>();

            foreach (var c in entityChunks)
            {
                var dto = c.Read<EntitySaveData>(); // снапшот сущности
                var def = itemCatalog.GetByKey(dto.definitionKey);
                var rt = itemFactory.Create(def, Vector3.zero, Quaternion.identity);

                if (Guid.TryParse(dto.entityId, out var gid))
                    rt.GetComponent<StableId>()?.SetFromSave(gid);

                rt.Restore(dto);
                created[rt.EntityId] = rt;
            }

            // (3) разложить по контейнерам (смотрим location у каждого dto)
            var registry = ServiceRegistry.Get<IEntityContainer>();
            foreach (var c in entityChunks)
            {
                var dto = c.Read<EntitySaveData>();
                if (dto.location?.kind == EEntityLocationKind.container &&
                    created.TryGetValue(dto.entityId, out var ent) &&
                    registry.TryGet(dto.location.ownerId, out var inv) &&
                    ent is BigHeart.ItemRuntime it)
                {
                    inv.Add(it, dto.location.index);
                }
            }

            // (4) остальные чанки — адресно компонентам по их SaveId
            var targets = UnityEngine.Object.FindObjectsOfType<MonoBehaviour>(true)
                .OfType<ISaveLoadObject>()
                .ToDictionary(o => o.ComponentSaveId, o => o);

            int applied = 0;
            foreach (var c in otherChunks)
                if (targets.TryGetValue(c.Id, out var obj))
                {
                    try
                    {
                        obj.RestoreData(c);
                        applied++;
                    }
                    catch (Exception ex) { Debug.LogException(ex); }
                }

            Debug.Log($"[Load] entities={created.Count}, components applied={applied}");
        }
    }
}
